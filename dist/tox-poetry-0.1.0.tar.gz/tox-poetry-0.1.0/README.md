# tox-poetry

[![PyPI version](https://badge.fury.io/py/tox-poetry.svg)](https://pypi.org/project/tox-poetry/)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/tox-poetry.svg?color=green)
[![Build Status](https://github.com/tkukushkin/tox-poetry/workflows/build/badge.svg?branch=master)](https://github.com/tkukushkin/tox-poetry/actions?query=workflow%3Abuild+branch%3Amaster)
[![codecov](https://codecov.io/gh/tkukushkin/tox-poetry/branch/master/graph/badge.svg)](https://codecov.io/gh/tkukushkin/tox-poetry)

## Usage:

Install plugin:

```bash
pip install tox-poetry
```

**PROFIT!**
